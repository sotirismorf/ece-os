#!/bin/bash

current_time=$(date +%s)

current_time_double=$(( 2*current_time ))

echo $current_time
echo $current_time_double

for i in {1..20}; do
	echo $i
done
